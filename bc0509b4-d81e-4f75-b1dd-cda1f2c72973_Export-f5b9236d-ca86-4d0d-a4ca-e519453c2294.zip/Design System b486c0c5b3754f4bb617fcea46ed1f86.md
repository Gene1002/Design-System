# Design System

Un sistema de diseño es un conjunto de estándares para el diseño y el código junto con los componentes que siguen estos estándares y se utilizan para construir páginas web. Ayuda a los equipos a crear productos digitales de alta calidad de manera más eficiente y coherente. Los sistemas de diseño pueden incluir guías de estilo, bibliotecas de componentes, patrones de diseño, documentación y otros recursos.

Bienvenido al sistema de diseño de Platzi, si estás aquí es porque quieres saber como construir más cosas para este increíble producto.

[Principios](https://www.notion.so/Principios-01655c7994c94d4fa3a904595ea58d94?pvs=21)

[Sistema](https://www.notion.so/Sistema-5137958b1d2d40dc8a3739319545ea49?pvs=21)

[Componentes](https://www.notion.so/Componentes-39c043f794f944e98c85a8e9e9f092d6?pvs=21)

[Fundations](https://www.notion.so/Fundations-0229a2a5e40546eb98f13b0037994e77?pvs=21)

[Proceso de iteración ](https://www.notion.so/Proceso-de-iteraci-n-7e02b749742e409e927bffecd10e50c8?pvs=21)

---

🖥**UI Kit [Ver](https://xd.adobe.com/spec/4837c5b3-895c-4fa6-52ef-1149b072cf7d-3e06/)  [Descargar](https://drive.google.com/file/d/1Hxw1fZm3OBfTIs17cj0N6NxhYemZXmVn/view?usp=sharing)**

---

Para ver mas proyectos puedes ingresar al siguiente enlace: [https://github.com/Gene1002/GOOGLECLONE](https://github.com/Gene1002/GOOGLECLONE)